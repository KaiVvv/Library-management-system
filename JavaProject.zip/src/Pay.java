import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;



public class Pay {
    public static void pay() {

        double sum = 0;
        System.out.println("书店管理系统>购物结算");
        System.out.println("***********书籍列表********");
        System.out.println("\t"+"书籍编号"+"\t"+"书籍名称"+"\t"+"书籍价格");
        List<Book> list = BookDao.searchAll();
        for (
                Book book0 : list
        ) {
            System.out.println("\t"+book0.getId()+"\t\t" + book0.getBookname() +"\t\t" +book0.getPrice());
        }


        System.out.println("********************");
        System.out.println("请输入会员号");
        Scanner sc = new Scanner(System.in);
        //sql  判断是否有此人  有则展示 无再次输入
        //63
        User flag = null;
        int id;
        do {

            id = sc.nextInt();
            flag = UserDao.searchById(id);
            if (flag == null) {
                System.out.println("有误重输入");
            }
        } while (flag == null);

        String choice = "";
        while (!choice.equals("n")) {


            System.out.println("请输入购买的书籍编号");
            sc = new Scanner(System.in);
            String bookId = sc.next();
            //判断是否存在编号 无重新 有继续
            Book book1;
            int bookNum;
            do {
                book1 = BookDao.searchById(bookId);
                if (book1 == null) {
                    System.out.println("编号不存在，重新输入");
                }
                //sql
                //  再写一个根据编号展示书籍信息
            } while (book1 == null);
            System.out.println("请输入要购买的数量：");
            bookNum = sc.nextInt();
            System.out.println("书籍编号"+"\t"+"书籍名称"+"\t"+"价格");
            System.out.println(book1.getBookname() + "\t\t" + book1.getPrice() + "\t\t" + book1.getPrice() * bookNum);
            sum = sum + book1.getPrice() * bookNum;
            System.out.println("是否继续？(Y or N)");
            choice = sc.next();
        }


        System.out.println("金额总计为：\t" + sum);
        System.out.print("交费金额:\t");
        System.out.println();
        double money = sc.nextDouble();
        System.out.println("找零：\t" + (money - sum));
        System.out.println("消费积分：\t" + (int) (sum / 10));
        System.out.println("购买成功");

        UserDao.updateById(id, (int) (sum / 10));



        Date time =new java.sql.Date(new java.util.Date().getTime());
        System.out.println(time);
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//注意月和小时的格式为两个大写字母
        java.util.Date date = new Date();//获得当前时间
        String day = df.format(date);//将当前时间转换成特定格式的时间字符串，这样便可以插入到数据库中

        int rows= UserDao.orderNumber(money,id,day);
    }
}





