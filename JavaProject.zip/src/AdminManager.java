import java.util.Scanner;

public class AdminManager {


    public static boolean isLogin() {
        Scanner sc = new Scanner(System.in);

        //循环输入3次，如果有一次正确，就直接终止循环，否则一直输入 ，直到输入3次后再终止循环
        for(int i =3;i>=1;i--) {
            System.out.println("请输入用户名：");
            //获取用户输入的账号
            String sysUser = sc.next();

            System.out.println("请输入密码：");
            String sysPwd = sc.next();

            //用户输入的账号和密码 在数据库中是否存在
            Sys sys = SysDao.searchByUsernameAndPassword(sysUser, sysPwd);

            //sys   值可能是  null：用户输入的不对     可能是对象：证明查到了

            if(sys == null) {
                //用户输入错误的账号和密码
                System.out.println("对不起，你输入的账号和密码不正确，请重新输入，您还有"+(i-1)+"次机会");
            }else {
                //用户输入正确
                return true;
            }

        }

        //如果代码能走到这，就是循环结束了，用户输入3次都没输入对
        System.out.println("用户名密码三次输入有误，系统自动退出");
        return false;
    }
}