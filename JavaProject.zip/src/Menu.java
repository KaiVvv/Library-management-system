import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        //登录页面
        System.out.println("        书店管理销售系统");
        System.out.println("***********************");
        System.out.println("     1.登录系统");
        System.out.println("     2.退出");
        System.out.println("***********************");

        Scanner sc = new Scanner(System.in);

        //定义一个标识符：状态码
        boolean flag = false;


        while (true) {
            System.out.println("请选择,输入数字:");
            //获取用户输入

            //声明一个变量nuo,保存用户输入的数字
            int uno = sc.nextInt();//1
            //用户输入1访问登录功能
            if (uno == 1) {
                //调用 AdminManager 管理员登录 访问登录功能
                boolean flag1 = AdminManager.isLogin();
                if (flag1) {
                    System.out.println("登录成功！");
                    //登录成功之后把开关打开

                    flag = true;
                    break;
                }
            } else if (uno == 2) {
                //退出系统
                System.out.println("谢谢使用，再见！");
                break;
            } else {
                System.out.println("请输入正确的编号！");

            }

        }


        if (flag) {//登录成功
            mainMenu();
        }

    }

    public static void showUserManager() {
        System.out.println("会员管理主界面");
        System.out.println("书店管理营销系统>会员管理");
        System.out.println();
        System.out.println("*****************************");
        System.out.println("\t1.显示所有会员");
        System.out.println("\t2.添加会员");
        System.out.println("\t3.修改会员");
        System.out.println("\t4.删除会员");
        System.out.println("\tm.返回主菜单");
        System.out.println("***********************");
        System.out.println("请选择功能");
        Scanner sc = new Scanner(System.in);
        String num;
        while (true) {
            num = sc.next();
            if (!num.equals("1") && !num.equals("2") && !num.equals("3") && !num.equals("m") && !num.equals("4")) {
                System.out.println("请输入正确的编号");
                continue;
            }
            break;
        }
        if (num.equals("1")) {
            UserManager.showUser();
            returnUserManageMenu();
        }
        if (num.equals("2")) {
            UserManager.addUser();
            returnUserManageMenu();
        }
        if (num.equals("3")) {
            UserManager.updateUser();
            returnUserManageMenu();
        }
        if (num.equals("4")) {
            UserManager.deleteUser();
            returnUserManageMenu();
        }
        if (num.equals("m")) {
            mainMenu();
        }

    }

    public static void returnUserManageMenu() {
        System.out.println("请输入'u'进行返回会员管理");
        Scanner sc = new Scanner(System.in);
        boolean flag = false;
        do {
            String str = sc.next();

            if ("u".equals(str)) {
                showUserManager();
                break;
            } else {
                System.out.println("请输入正确的编号!");
                flag = true;
            }
        } while (flag);
    }

    public static void returnBookManageMenu() {
        System.out.println("请输入'b'进行返回书籍管理");
        Scanner sc = new Scanner(System.in);
        boolean flag = false;
        do {
            String str = sc.next();

            if ("b".equals(str)) {
                showBooksManage();
                break;
            } else {
                System.out.println("请输入正确的编号!");
                flag = true;
            }
        } while (flag);
    }




    public static void mainMenu() {
        System.out.println();
        System.out.println("书店管理销售系统");
        System.out.println("*************************");
        System.out.println("\t1.会员管理");
        System.out.println("\t2.书籍管理");
        System.out.println("\t3.购物结算");

        System.out.println("\t4.积分兑换礼品");

        System.out.println("\t5.注销");
        System.out.println("\t6.借阅图书");
        System.out.println("\t7.归还图书");
        System.out.println("*************************");
        System.out.println("请选择，输入数字：");

        int input;
        Scanner sc = new Scanner(System.in);
        while (true) {
            input = sc.nextInt();

            if (input < 1 || input > 8) {
                System.out.println("请输入正确的编号");
                continue;
            }
            break;
        }
        switch (input) {
            case 1:
                showUserManager();
                break;
            case 2:
                showBooksManage();
                break;
            case 3:
                Pay.pay();
                returnMainMenu();
                break;
            case 4:
                GiftManager.exchange();
                break;
            case 5:
                return;
            // break;
            case 6:
                borrowBook();
                mainMenu();
                break;
            case 7:
                returnBook();
                mainMenu();
                break;
        }

    }

    private static void showBooksManage() {
        System.out.println("书店管理系统>书籍管理");
        System.out.println("**************");
        System.out.println("\t1.查看书目");
        System.out.println("\t2.添加书籍");
        System.out.println("\t3.删除书籍");
        System.out.println("\tm.返回主菜单");
        System.out.println("**************");
        System.out.println("请选择功能");
        Scanner sc = new Scanner(System.in);
        String input = sc.next();
        while (true) {
            if (!input.equals("1") && !input.equals("2") && !input.equals("3") && !input.equals("m")) {
                System.out.println("请输入正确的功能编号");
                continue;
            }
            break;

        }
        if (input.equals("1")) {
            BookManager.showBooks();
            returnBookManageMenu();
        }
        if (input.equals("2")) {
            BookManager.addBook();
            returnBookManageMenu();
        }
        if (input.equals("3")) {
            BookManager.deletebook();
            returnBookManageMenu();
        }
        if (input.equals("m")) {
            mainMenu();
        }
    }

    public static void borrowBook() {
        System.out.println("书店管理销售系统>图书借阅");
        System.out.println("请输入会员号：");
        Scanner sc = new Scanner(System.in);
        String sid = sc.next();
        student s = studentDao.searchById(sid);
        // s = library.queryStudentsById(sid);
        if (s != null) {
            System.out.println("请输入图书编号：");
            String id = sc.next();
            studentManager.borrowBooks(sid, id);
            mainMenu();
        } else {
            System.out.println("查无此人");
            mainMenu();
        }

    }

    public static void returnBook() {
        System.out.println("书店管理销售系统>图书归还");
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入会员号：");
        String sid = sc.next();
        student s = studentDao.searchById(sid);
        if (s != null) {
            System.out.println("请输入书籍编号：");
            String bookid = sc.next();
            studentManager.returnBooks(bookid);

        } else {
            System.out.println("查无此人");
        }
    }

    public static void returnMainMenu() {
        System.out.println("请输入'm'进行返回会员管理");
        Scanner sc = new Scanner(System.in);
        boolean flag = false;
        do {
            String str = sc.next();

            if ("m".equals(str)) {
                showUserManager();
                mainMenu();
                break;
            } else {
                System.out.println("请输入正确的编号!");
                flag = true;
            }
        } while (flag);
    }


}
