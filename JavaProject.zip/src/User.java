public class User {
    private int id;
    private int age;
    private int jifen;

    public User(int id, int age, int jifen) {
        this.id = id;
        this.age = age;
        this.jifen = jifen;
    }
    public User(int id) {
        this.id = id;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getJifen() {
        return jifen;
    }

    public void setJifen(int jifen) {
        this.jifen = jifen;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", age=" + age +
                ", jifen=" + jifen +
                '}';
    }
}
