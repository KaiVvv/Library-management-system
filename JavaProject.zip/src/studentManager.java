import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class studentManager {

    public static boolean returnBooks(String bookid) {

        int rows = 0;

        rows = studentDao.updataById1(bookid);

        if (rows != 0) {

            System.out.println("还书成功！");
            return true;


        } else {
            System.out.println("查询失败，您没有借此书！");
            return false;
        }
    }


    public static boolean borrowBooks(String sid, String id) {
        Book b;
        do {


            Scanner in = new Scanner(System.in);


            b = null;
            b = BookDao.searchById(id);
            if (b == null) {
                System.out.println("图书不存在，借书失败！");
                System.out.println("请重新输入正确编号");
                id = in.next();

            }
        } while (b == null);
        student student = new student();

        studentDao.isBorrow(b.getBookname(), student.getSid());

        System.out.println("借书成功！");

        int rows = 0;
        rows = studentDao.updataById(sid, id);
        if (rows != 0) {
            System.out.println("用户信息更新完成");
        } else {
            System.out.println("信息更新失败");
        }
        return true;


    }

}
