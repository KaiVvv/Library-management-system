import java.util.HashMap;
import java.util.Map;

public class student {

    private String sid; // 学号
    private String name;// 姓名
    private Map<Book, Integer> books; // 表示学生借的所有图书

    public student() {

    }

    public student(String sid, String name) {
        this.sid = sid;
        this.name = name;
        books = new HashMap<Book, Integer>();
    }
    public student(String sid) {
        this.sid = sid;

    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<Book, Integer> getBooks() {
        return books;
    }

    public void setBooks(Map<Book, Integer> books) {
        this.books = books;
    }
}