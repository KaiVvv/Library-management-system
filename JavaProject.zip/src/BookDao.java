import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDao {
    public static List<Book> searchAll() {
        List<Book> list = new ArrayList<>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user = "root";
            String password = "root";

            //获取连接
            Connection conn = DriverManager.getConnection(url, user, password);

            //定义sql   要改
            String sql = "select * from book";
//

            //预编译sql
            PreparedStatement ps = conn.prepareStatement(sql);


            //执行sql,查询是有数据结果集合的  ResultSet结果集合
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                //进一次循环，就获取一条记录
                String id = rs.getString("id");
                String bookname = rs.getString("bookname");
                double price = rs.getDouble("price");

                //通过有参构造 创建一个对象
              Book  book = new Book(id, bookname, price);
//				System.out.println("id:"+id+",name:"+name+",sex:"+sex+",age:"
//				+age+",phone:"+phone+",birth:"+birth+",score:"+score);
                list.add(book);

            }

            rs.close();
            ps.close();
            conn.close();

//
        } catch (ClassNotFoundException | SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }

    public static int add(Book book) {
        int rows = 0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user = "root";
            String password = "root";

            //获取连接
            Connection conn = DriverManager.getConnection(url, user, password);

            //定义sql   要改
            String sql = "insert into book(bookname,price) value(?,?)";
//

            //预编译sql
            PreparedStatement ps = conn.prepareStatement(sql);
          //  ps.setInt(1,book.getId());
            ps.setString(1,book.getBookname());
            ps.setDouble(2,book.getPrice() );
            rows = ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return 0;

    }

    public static int deleteByBookname(String bookname)
        {
            int rows=0;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
                String user="root";
                String password="root";
                Connection conn=DriverManager.getConnection(url,user,password);
                String sql="DELETE FROM book WHERE id =?";
                PreparedStatement ps =conn.prepareStatement(sql);

                ps.setString(1,bookname);
                rows=ps.executeUpdate();

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            return rows;
        }

    public static int updateById(int id,String newBookname,int newPrice)
    {
        int rows=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="update book set bookname =?,price=? where id=?";
            PreparedStatement ps =conn.prepareStatement(sql);
            ps.setString(1,newBookname);
            ps.setInt(2,newPrice);
            ps.setInt(3,id);
            rows=ps.executeUpdate();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rows;
    }
    public static Book searchById(String id)
    {
        Book book=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="select * from book where id =?";
            PreparedStatement ps =conn.prepareStatement(sql);
            ps.setString(1,id);
            ResultSet rs=ps.executeQuery();
            if (rs.next())
            {
                id=rs.getString("id");
                 String bookname =rs.getString("bookname");
                double price=rs.getInt("price");
                book=new Book(id,bookname,price);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return book;
    }

}
