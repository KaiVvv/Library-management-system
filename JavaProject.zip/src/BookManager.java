import java.util.List;
import java.util.Scanner;

public class BookManager {
    public static void showBooks()
    {
        System.out.println("书店管理营销系统>书籍管理>书籍列表");
       List<Book> list= BookDao.searchAll();
        for (Book book:list
             ) {
            System.out.println("编号"+book.getId()+"\t书名"+book.getBookname()+"\t价格"+book.getPrice());
        }

    }

    public static void addBook() {
        System.out.println("书店管理营销系统>书籍管理>书籍列表>添加书籍");
        System.out.println("请输入要添加的书名：");
        //自己写数据库
        Scanner sc = new Scanner(System.in);
        String bookname=sc.next();

        System.out.println("请输入价格");
       double price= sc.nextDouble();
       Book book=new Book();
        book.setBookname(bookname);
       book.setPrice(price);

       BookDao.add(book);
        System.out.println("添加成功");

    }

    public static void deletebook() {
        System.out.println("书店管理营销系统>书籍管理>书籍列表>书籍下架：");
        System.out.println("请输入要删除的书的id：");
        Scanner sc = new Scanner(System.in);
        String id=sc.next();
        //数据库先查询是否存在
       Book book= BookDao.searchById(id);
       if (book!=null) {
           int rows = BookDao.deleteByBookname(book.getBookname());
           if (rows > 0) {
               System.out.println("删除成功");
           } else {
               System.out.println("删除失败");
           }
       }
       else {
           System.out.println("没有找到这本书");
       }
    }
}
