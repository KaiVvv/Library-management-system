import java.util.List;
import java.util.Scanner;

public class GiftManager {
    public static void exchange() {
        System.out.println("书店管理销售系统>积分兑换礼品");
        System.out.println("***********礼品清单******************");
        System.out.println("礼品编号\t礼品名称\t兑换所需积分");
       List<Gift> list = GiftDao.searchAll();
        Gift gift=null;
        for (Gift gift1:list
             ) {
            System.out.println(gift1.getId()+"\t"+gift1.getGiftname()+"\t"+gift1.getJifen());
        }
            System.out.println("**************");
            System.out.println("请输入会员号");
            Scanner sc = new Scanner(System.in);
            int userId=sc.nextInt();
            //连接数据库 获取
           User user= UserDao.searchById(userId);
            System.out.println("请选择你需要兑换的礼品编号：");
            int giftId= sc.nextInt();
            //根据礼品编号 查询信息
            Gift gift1=GiftDao.searchById(giftId);
            System.out.println("您成功兑换了一个"+gift1.getGiftname()+",您剩余"+(user.getJifen()-gift1.getJifen())+"分");
            //根据编号更新用户积分
          int rows=  UserDao.updateById(userId,user.getJifen()-gift1.getJifen());
          if (rows>0)
          {
              System.out.println("积分更新成功");

             Menu.mainMenu();
          }
          else {
              System.out.println("更新失败");
          }
        }
    }

