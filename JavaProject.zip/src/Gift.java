public class Gift {
    private int id;
    private String giftname;
    private int jifen;

    public Gift(int id, String giftname, int jifen) {
        this.id = id;
        this.giftname = giftname;
        this.jifen = jifen;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGiftname() {
        return giftname;
    }

    public void setGiftname(String giftname) {
        this.giftname = giftname;
    }

    public int getJifen() {
        return jifen;
    }

    public void setJifen(int jifen) {
        this.jifen = jifen;
    }

    @Override
    public String toString() {
        return "Gift{" +
                "id=" + id +
                ", giftname='" + giftname + '\'' +
                ", jifen=" + jifen +
                '}';
    }
}
