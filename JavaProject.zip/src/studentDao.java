import java.sql.*;

public class studentDao {

    public static student searchById(String id)
    {
        student u=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="select * from stu where id =?";
            PreparedStatement ps =conn.prepareStatement(sql);
            ps.setString(1,id);
            ResultSet rs=ps.executeQuery();
            if (rs.next())
            {
                id=rs.getString("id");

                u=new student(id);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return u;
    }
    public static boolean isUse(String id)
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user = "root";
            String password  = "root";

            //获取连接
            Connection conn = DriverManager.getConnection(url, user, password);

            //定义sql   as num 起别名
            String sql  = "select count(*) as stu from user where id=?";
//

            //预编译sql
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1,id);

            //执行sql,查询是有数据结果集合的  ResultSet结果集合
            ResultSet rs = ps.executeQuery();
            int num=0;
            if (rs.next())
            {
                num= rs.getInt("num");
            }
            rs.close();
            ps.close();
            conn.close();
            if(num==0)
            {
                return true;
            }
            else {
                return false;
            }



//			System.out.println("结果集合："+rs);	//结果集合：com.mysql.jdbc.JDBC42ResultSet@10a035a0  对象地址
        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();
        }

        return false;
    }
    public static int isBorrow(String getBookname,String Sid )
    {
        int rows=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="update stu set books =? where id=?";
            PreparedStatement ps =conn.prepareStatement(sql);
            ps.setString(1,getBookname);
            ps.setString(2,Sid);

            rows=ps.executeUpdate();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rows;
    }
    public static int deleteBybookid(String bookid)
    {
        int rows=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="DELETE FROM stu WHERE books =?";
            PreparedStatement ps =conn.prepareStatement(sql);

            ps.setString(1,bookid);
            rows=ps.executeUpdate();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rows;
    }

    public static int updataById(String id,String books) {
        int rows=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="update stu set books=? where id=?";
            PreparedStatement ps =conn.prepareStatement(sql);
            ps.setString(1,books);
            ps.setString(2,id);

            rows=ps.executeUpdate();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rows;
    }

    public static int updataById1(String id) {
        int rows=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="update stu set books=0 where books=?";
            PreparedStatement ps =conn.prepareStatement(sql);
            ps.setString(1,id);


            rows=ps.executeUpdate();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rows;
    }
}
