public class Sys {
    private int id;
    private String username;
    private String password;
    //生成get/set 方法
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }


    //生成toString 方法
    @Override
    public String toString() {
        return "Sys [id=" + id + ", username=" + username + ", password=" + password + "]";
    }

    public Sys() {

    }
    //生成带参方法
    public Sys(int id, String username, String password) {
        super();
        this.id = id;
        this.username = username;
        this.password = password;
    }

}