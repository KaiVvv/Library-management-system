import java.util.List;
import java.util.Scanner;

public class UserManager {
    public static void showUser()
    {
        System.out.println("书店管理销售系统>会员信息管理>显示会员信息");
        System.out.println("\t会员号 \t年龄 \t积分");
        List<User> list=UserDao.searchAll();
        for (User user:list) {
            System.out.println("\t "+user.getId()+"\t\t "+ user.getAge()+"\t\t "+ user.getJifen());
            
        }
    }
    public static void addUser()
    {
        System.out.println("添加会员信息界面");
        System.out.println("书店管理营销系统>会员信息管理>新增会员信息");
        System.out.println("请输入会员编号：");
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        boolean flag=UserDao.isUse(num);
        if (!flag)
        {
            System.out.println("该编号已经存在，不能重复添加！添加失败");
        }else
        {
            System.out.println("请输入会员年龄：");
            int age=sc.nextInt();
            System.out.println("请输入会员积分");
            int jifen=sc.nextInt();
            User user=new User(num,age,jifen);

            int rows=UserDao.addUser(user);
            if(rows==1)
            {
                System.out.println("添加成功");
            }
            else {
                System.out.println("添加失败");
            }
        }
    }

    public static void updateUser() {
        System.out.println("书店管理销售系统>会员信息管理>修改会员信息");
        System.out.println("请输入会员编号");
        Scanner sc = new Scanner(System.in);
        int id= sc.nextInt();
        User u=UserDao.searchById(id);
        if (u==null)
        {
            System.out.println("找不到编号为"+id+"的会员信息，修改失败");

        }else
        {
            System.out.println(id+"号会员的年龄是"+u.getAge()+"积分是："+u.getJifen());
            System.out.println("请输入会员的新年龄");
            int age= sc.nextInt();
            System.out.println("请输入会员的新积分");
            int jifen= sc.nextInt();
            int rows=UserDao.updateById(id,age,jifen);
            if(rows>0)
            {
                System.out.println("修改成功");

            }else
            {
                System.out.println("修改失败");
            }
        }
    }

    public static void deleteUser() {
        System.out.println("书店管理销售系统>会员信息管理>删除会员信息");
        System.out.println("请输入会员编号");
        Scanner sc = new Scanner(System.in);
        int id= sc.nextInt();
        User u=UserDao.searchById(id);
        if (u==null)
        {
            System.out.println("找不到编号为"+id+"的会员信息，删除失败");

        }else
        {
            System.out.println(id+"号会员的年龄是"+u.getAge()+"积分是："+u.getJifen());
            int rows=UserDao.deleteById(id);
            if(rows>0)
            {
                System.out.println("删除成功");

            }else
            {
                System.out.println("删除失败");
            }
        }

    }
}
