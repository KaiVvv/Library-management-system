import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class UserDao {
    public static boolean isUse(int id)
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user = "root";
            String password  = "root";

            //获取连接
            Connection conn = DriverManager.getConnection(url, user, password);

            //定义sql   as num 起别名
            String sql  = "select count(*) as num from user where id=?";
//

            //预编译sql
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1,id);

            //执行sql,查询是有数据结果集合的  ResultSet结果集合
            ResultSet rs = ps.executeQuery();
            int num=0;
            if (rs.next())
            {
               num= rs.getInt("num");
            }
            rs.close();
            ps.close();
            conn.close();
            if(num==0)
            {
                return true;
            }
            else {
            return false;
            }




//			System.out.println("结果集合："+rs);	//结果集合：com.mysql.jdbc.JDBC42ResultSet@10a035a0  对象地址
        } catch (ClassNotFoundException | SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

return false;
    }
    public static List<User> searchAll()
    {
        List<User> list = new ArrayList();
        ///return list;
        //public static User searchByUsernameAndPassword(int  id,int age,int jifen) {
        User u = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user = "root";
            String password  = "root";

            //获取连接
            Connection conn = DriverManager.getConnection(url, user, password);

            //定义sql   要改
            String sql  = "select * from user";
//

            //预编译sql
            PreparedStatement ps = conn.prepareStatement(sql);


            //执行sql,查询是有数据结果集合的  ResultSet结果集合
            ResultSet rs = ps.executeQuery();

            //数据已经在rs中了，需要 遍历rs来获取想要 的数据  for  while
            // rs.next() 做了两件事
            //1.返回一个boolean值 ，是否有下一个元素，true:有下个元素，进入循环体   false:没有元素，终止循环
            //2.游标往下走一行
           while(rs.next()) {
                //进一次循环，就获取一条记录
               int id = rs.getInt("id");
                int  age = rs.getInt("age");
                int  jifen = rs.getInt("jifen");

                //通过有参构造 创建一个对象
                u = new User(id, age, jifen);
//				System.out.println("id:"+id+",name:"+name+",sex:"+sex+",age:"
//				+age+",phone:"+phone+",birth:"+birth+",score:"+score);
                list.add(u);

            }
            rs.close();
            ps.close();
            conn.close();

//			System.out.println("结果集合："+rs);	//结果集合：com.mysql.jdbc.JDBC42ResultSet@10a035a0  对象地址
        } catch (ClassNotFoundException | SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;

    }
    public static int addUser(User addUser)
    {
        int rows=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user = "root";
            String password = "root";

            //获取连接
            Connection conn = DriverManager.getConnection(url, user, password);
            //
            String sql="insert into user(id,age,jifen) value(?,?,?)";
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setInt(1,addUser.getId());
            ps.setInt(2,addUser.getAge());
            ps.setInt(3,addUser.getJifen());
          rows= ps.executeUpdate();

        ps.close();
        conn.close();

//			System.out.println("结果集合："+rs);	//结果集合：com.mysql.jdbc.JDBC42ResultSet@10a035a0  对象地址
    } catch (ClassNotFoundException | SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

            return rows;
    }

public static User searchById(int id)
{
    User u=null;
    try {
        Class.forName("com.mysql.jdbc.Driver");
        String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
        String user="root";
        String password="root";
        Connection conn=DriverManager.getConnection(url,user,password);
        String sql="select * from user where id =?";
        PreparedStatement ps =conn.prepareStatement(sql);
        ps.setInt(1,id);
        ResultSet rs=ps.executeQuery();
        if (rs.next())
        {
            id=rs.getInt("id");
            int age =rs.getInt("age");
            int jifen=rs.getInt("jifen");
             u=new User(id,age,jifen);
        }
    } catch (ClassNotFoundException e) {
       e.printStackTrace();
    } catch (SQLException e) {
        throw new RuntimeException(e);
    }
    return u;
}
public static int updateById(int id,int newAge,int newJifen)
{
    int rows=0;
    try {
        Class.forName("com.mysql.jdbc.Driver");
        String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
        String user="root";
        String password="root";
        Connection conn=DriverManager.getConnection(url,user,password);
        String sql="update user set age =?,jifen=? where id=?";
        PreparedStatement ps =conn.prepareStatement(sql);
        ps.setInt(1,newAge);
        ps.setInt(2,newJifen);
        ps.setInt(3,id);
       rows=ps.executeUpdate();

    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    } catch (SQLException e) {
        throw new RuntimeException(e);
    }
    return rows;
}
    public static int deleteById(int id)
    {
        int rows=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="DELETE FROM user WHERE id =?";
            PreparedStatement ps =conn.prepareStatement(sql);

            ps.setInt(1,id);
            rows=ps.executeUpdate();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rows;
    }
    public static int updateById(int id,int newJifen)
    {
        int rows=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="update user set jifen=? where id=?";
            PreparedStatement ps =conn.prepareStatement(sql);
            ps.setInt(1,newJifen);
            ps.setInt(2,id);

            rows=ps.executeUpdate();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rows;
    }

    public static int  orderNumber(double money, int userid,String day) {
        int rows=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user = "root";
            String password = "root";

            //获取连接
            Connection conn = DriverManager.getConnection(url, user, password);
            //
            String sql="insert into `order`(money,userid,datetime) values(?,?,?)";
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setDouble(1,money);
            ps.setInt(2,userid);

            ps.setString(3, day);
            rows= ps.executeUpdate();

            ps.close();
            conn.close();

//			System.out.println("结果集合："+rs);	//结果集合：com.mysql.jdbc.JDBC42ResultSet@10a035a0  对象地址
        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();
        }

        return rows;
    }

}

