import java.sql.*;

public class SysDao {



    public static Sys searchByUsernameAndPassword(String sysUser,String sysPwd) {
        Sys s = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user = "root";
            String password  = "root";

            //获取连接
            Connection conn = DriverManager.getConnection(url, user, password);

            //定义sql   要改
            String sql  = "select * from sys where username = ? and password  = ?";
//			String sql = "select * from stu where name = ?";

            //预编译sql
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, sysUser);
            ps.setString(2, sysPwd);

            //执行sql,查询是有数据结果集合的  ResultSet结果集合
            ResultSet rs = ps.executeQuery();


            if(rs.next()) {
                //进一次循环，就获取一条记录
                int id = rs.getInt("id");

                String uname = rs.getString("username");
                String pwd = rs.getString("password");


                s = new Sys(id, uname, pwd);


            }
            rs.close();
            ps.close();
            conn.close();

//			System.out.println("结果集合："+rs);	//结果集合：com.mysql.jdbc.JDBC42ResultSet@10a035a0  对象地址
        } catch (ClassNotFoundException | SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return s;

    }

}