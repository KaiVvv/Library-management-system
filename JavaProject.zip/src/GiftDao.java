import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GiftDao {


    public static List<Gift> searchAll() {
        List<Gift> list = new ArrayList<>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user = "root";
            String password = "root";

            //获取连接
            Connection conn = DriverManager.getConnection(url, user, password);

            //定义sql   要改
            String sql = "select * from gift";
//

            //预编译sql
            PreparedStatement ps = conn.prepareStatement(sql);


            //执行sql,查询是有数据结果集合的  ResultSet结果集合
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                //进一次循环，就获取一条记录
                int id = rs.getInt("id");
                String bookname = rs.getString("Giftname");
                int jifen = rs.getInt("jifen");

                //通过有参构造 创建一个对象
                Gift gift = new Gift(id, bookname,jifen);
//				System.out.println("id:"+id+",name:"+name+",sex:"+sex+",age:"
//				+age+",phone:"+phone+",birth:"+birth+",score:"+score);
                list.add(gift);

            }

            rs.close();
            ps.close();
            conn.close();

//
        } catch (ClassNotFoundException | SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }
    public static Gift searchById(int id)
    {
        Gift u=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/kai?characterEncoding=utf-8";
            String user="root";
            String password="root";
            Connection conn=DriverManager.getConnection(url,user,password);
            String sql="select * from gift where id =?";
            PreparedStatement ps =conn.prepareStatement(sql);
            ps.setInt(1,id);
            ResultSet rs=ps.executeQuery();
            if (rs.next())
            {
                id=rs.getInt("id");
                String Giftname =rs.getString("Giftname");
                int jifen=rs.getInt("jifen");
                u=new Gift(id,Giftname,jifen);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return u;
    }
}
